import { test, expect } from '@playwright/test';

test(`TextContent and GetAttribute test`, async ({ page }) => {
  await page.goto('https://github.com/bakkappaN/');
  const name= await page.locator('[itemprop="name"]').textContent();
  console.log(`Name is : ${name?.trim()}`)
    
});

